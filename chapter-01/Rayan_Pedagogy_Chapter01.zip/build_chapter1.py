from pathlib import Path
from docx import Document
from docx.shared import Mm, Pt, RGBColor
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
import shutil, json, zipfile, html

ROOT=Path(__file__).parent
OUT=ROOT/'output'
OUT.mkdir(exist_ok=True)
(OUT/'assets').mkdir(exist_ok=True)
shutil.copy2(ROOT.parent/'output/course_brochure/assets/rayan-logo.png',OUT/'assets/rayan-logo.png')
pages=[
('فصل اول کلیات پداگوژی',[
('p','جزوه‌ی مطالعه برای مربیان آموزشگاه رایان'),
('h','هدف مطالعه'),
('p','پس از مطالعه، مربی باید آموزش را توضیح دهد، پنج بخش فرایند آموزش را نام ببرد و برای یک فعالیت آموزشی، نیاز، هدف، مواد، اجرا و روش ارزشیابی را مشخص کند.'),
('h','وضعیت این نسخه'),
('p','پیش‌نویس بر اساس متن و نمودارهای قابل مشاهده‌ی فصل اول است. صدای درس در ابزار بررسی در دسترس نبود؛ این نسخه هنوز با گفتار مدرس تطبیق داده نشده است.'),
('p','محتوای فصل شامل اهداف درس، تعریف آموزش، آموزش اثربخش، فرایند آموزش و مفهوم پداگوژی است. توضیح‌های کاربردی و مثال رایان، تدوین تکمیلی این جزوه هستند.'),
('p','منبع اصلی: فصل اول «کلیات» از پودمان «پداگوژی و آموزش‌های فنی و حرفه‌ای»، سامانه‌ی آموزش مجازی شاهوار. تاریخ بررسی: ۲۲ آبان ۱۴۰۵.')]),
('آموزش و اثربخشی آن',[
('h','تعریف آموزش در فصل'),
('p','در این فصل، آموزش مجموعه‌ای از فرایندهای منظم است که برای دستیابی به اهداف یادگیری مرتبط با شغل کنونی و آینده‌ی فراگیر طراحی می‌شود.'),
('h','نقطه‌ی شروع آموزش اثربخش'),
('p','اسلاید آموزش اثربخش بر شناخت نیازهای جامعه، سازمان و افراد تأکید دارد. مربی پیش از انتخاب محتوا، باید بداند فراگیر چه کاری را باید یاد بگیرد و چه نیازی با انجام آن کار برطرف می‌شود.'),
('h','توضیح کاربردی تدوین‌کننده'),
('p','هدف را با یک کار قابل مشاهده بنویسید. برای نمونه، «فراگیر بتواند برای یک تمرین، هدف و روش بررسی نتیجه را بنویسد» قابل بررسی‌تر از «فراگیر آموزش را بهتر بفهمد» است.'),
('p','در بررسی نتیجه، محصول کار فراگیر و میزان کمک مربی را ثبت کنید. سپس تمرینی را تعیین کنید که فراگیر در نوبت بعد با کمک کمتر انجام دهد.'),
('p','نکته‌ی مطالعه: این توضیح کاربردی، بازنویسی گفتار مدرس نیست و برای استفاده‌ی مربی افزوده شده است.')]),
('پنج بخش فرایند آموزش',[
('p','نمودار فصل، نیازسنجی آموزشی، طراحی آموزشی، تدوین محتوا و مواد آموزشی، اجرای آموزش و ارزشیابی آموزشی را به هم پیوند می‌دهد. ارزشیابی به اصلاح بخش‌های دیگر بازخورد می‌دهد.'),
('table',[
['بخش','کار مربی در کاربرد عملی'],
['نیازسنجی آموزشی','وضع موجود و عملکرد مورد انتظار را مشخص می‌کند.'],
['طراحی آموزشی','هدف، ترتیب فعالیت‌ها و روش بررسی یادگیری را تعیین می‌کند.'],
['تدوین مواد آموزشی','محتوا، تمرین، نمونه و ابزار لازم را آماده می‌کند.'],
['اجرای آموزش','فعالیت را اجرا می‌کند و به عملکرد فراگیر بازخورد می‌دهد.'],
['ارزشیابی آموزشی','شواهد یادگیری را بررسی می‌کند و اصلاح لازم را پیشنهاد می‌دهد.']]),
('p','عنوان بخش‌ها از نمودار فصل گرفته شده است. شرح کار مربی، توضیح کاربردی تدوین‌کننده است.'),
('p','در یک اسلاید دیگر، «جمع‌آوری اطلاعات» و «تجزیه و تحلیل اطلاعات» نمایش داده می‌شوند. مربی باید اطلاعات را بررسی کند تا انتخاب فعالیت آموزشی به نیاز مشخص پاسخ دهد.')]),
('پداگوژی و تمرین مرور',[
('h','مفهوم پداگوژی'),
('p','اسلاید پایانی واژه‌ی pedagogy را با دو جزء Pais و Agogos نشان می‌دهد و تصویر مربی و کودکان را به کار می‌برد. شرح کامل گفتاری این بخش باید پس از دریافت صوت تکمیل شود.'),
('h','مثال فرضی برای آموزشگاه رایان'),
('p','نیاز: هنرجو هنگام تغییر اندازه‌ی شکل، نتیجه را پیش‌بینی نمی‌کند. هدف: هنرجو طول ضلع مربع را از ۸۰ به ۱۲۰ تغییر دهد و پیش از اجرا، بزرگ‌تر شدن شکل را پیش‌بینی کند.'),
('p','مواد و اجرا: مربی یک برنامه‌ی آماده و برگه‌ی ثبت پیش‌بینی می‌دهد. هنرجو عدد را تغییر می‌دهد، پیش‌بینی را می‌نویسد و برنامه را اجرا می‌کند. مربی ابتدا با یک پرسش کوتاه راهنمایی می‌کند.'),
('p','ارزشیابی فرضی: هنرجو تغییر اول را با یک پرسش مربی انجام داد. تمرین بعدی این است که هنرجو اندازه‌ی دیگری انتخاب کند و نتیجه را بدون راهنمایی پیش‌بینی کند.'),
('h','پرسش‌های مرور'),
('p','۱. آموزش در این فصل چگونه تعریف می‌شود؟ ۲. پنج بخش فرایند آموزش کدام‌اند؟ ۳. ارزشیابی چگونه به اصلاح آموزش کمک می‌کند؟ ۴. برای یک فعالیت خود، نیاز و هدف قابل مشاهده بنویسید.')])]

doc=Document(); sec=doc.sections[0]
sec.page_width=Mm(210);sec.page_height=Mm(148)
sec.top_margin=Mm(24);sec.bottom_margin=Mm(16);sec.left_margin=sec.right_margin=Mm(13)
sec.header_distance=Mm(5);sec.footer_distance=Mm(6)
doc.core_properties.title='جزوه‌ی فصل اول کلیات پداگوژی'
doc.core_properties.author='آموزشگاه رایان'
for name in ['Normal','Title','Heading 1','Heading 2']:
 s=doc.styles[name];s.font.name='B Nazanin';s.font.size=Pt(12 if name=='Normal' else 18 if name=='Title' else 13)
 s.font.color.rgb=RGBColor.from_string('14334D' if name!='Title' else '000000')
 s.element.get_or_add_rPr().append(parse_xml('<w:rFonts xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" w:ascii="B Nazanin" w:hAnsi="B Nazanin" w:cs="B Nazanin"/>'))
 s.paragraph_format.space_after=Pt(4)
 s.paragraph_format.line_spacing=1.1

def rtl(p):
 pp=p._p.get_or_add_pPr();e=OxmlElement('w:bidi');pp.append(e)
 p.alignment=0
 for r in p.runs:
  rp=r._r.get_or_add_rPr();rp.append(OxmlElement('w:rtl'));r.font.name='B Nazanin'
  size=r.font.size or p.style.font.size
  sz=OxmlElement('w:szCs');sz.set(qn('w:val'),str(round((size.pt if size else 12)*2)));rp.append(sz)

hp=sec.header.paragraphs[0]
hp.add_run().add_picture(str(OUT/'assets/rayan-logo.png'),width=Mm(21))
hp.add_run('     آموزشگاه رایان  |  پداگوژی  |  فصل اول')
rtl(hp)
wm='''<w:r xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office"><w:pict><v:shape id="RayanWatermark" type="#_x0000_t136" style="position:absolute;width:230pt;height:85pt;rotation:325;z-index:-251654144;mso-position-horizontal:center;mso-position-horizontal-relative:page;mso-position-vertical:center;mso-position-vertical-relative:page" fillcolor="#E9E4E6" stroked="f"><v:textpath style="font-family:&quot;B Nazanin&quot;;font-size:65pt" string="رایان" on="t"/><v:path textpathok="t"/><v:lock v:ext="edit" text="t" shapetype="t"/></v:shape></w:pict></w:r>'''
from PIL import Image, ImageDraw, ImageFont
water=Image.new('RGBA',(1000,600),(255,255,255,0))
wd=ImageDraw.Draw(water);wf=ImageFont.truetype('C:/Windows/Fonts/BNazanin.ttf',240)
wd.text((500,300),'رایان',font=wf,anchor='mm',fill=(233,228,230,150))
water=water.rotate(30,expand=False)
water.save(OUT/'assets/rayan-watermark.png')
pic=hp.add_run().add_picture(str(OUT/'assets/rayan-watermark.png'),width=Mm(105),height=Mm(63))._inline
anchor=OxmlElement('wp:anchor')
for k,v in {'distT':'0','distB':'0','distL':'0','distR':'0','simplePos':'0','relativeHeight':'0','behindDoc':'1','locked':'0','layoutInCell':'1','allowOverlap':'1'}.items():anchor.set(k,v)
sp=OxmlElement('wp:simplePos');sp.set('x','0');sp.set('y','0');anchor.append(sp)
for axis in ['H','V']:
 pos=OxmlElement('wp:position'+axis);pos.set('relativeFrom','page');al=OxmlElement('wp:align');al.text='center';pos.append(al);anchor.append(pos)
anchor.append(pic.find(qn('wp:extent')));anchor.append(OxmlElement('wp:wrapNone'))
for name in ['wp:docPr','wp:cNvGraphicFramePr','a:graphic']:
 e=pic.find(qn(name))
 if e is not None:anchor.append(e)
pic.getparent().replace(pic,anchor)
fp=sec.footer.paragraphs[0];fp.add_run('پیش‌نویس بر اساس اسلایدها     |     رایان     |     ')
f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');fp._p.append(f);rtl(fp)
for i,(title,items) in enumerate(pages):
 p=doc.add_paragraph(title,'Title' if i==0 else 'Heading 1');rtl(p)
 if i:p.paragraph_format.page_break_before=True
 for kind,value in items:
  if kind=='table':
   t=doc.add_table(rows=0,cols=2);t.autofit=False;t.columns[0].width=Mm(40);t.columns[1].width=Mm(140)
   t._tbl.tblPr.append(OxmlElement('w:bidiVisual'))
   for n,row in enumerate(value):
    cells=t.add_row().cells
    for c,text in zip(cells,row):
     c.text=text
     for p in c.paragraphs:rtl(p)
     pr=c._tc.get_or_add_tcPr();shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'14334D' if n==0 else 'F2F4F6' if n%2 else 'FFFFFF');pr.append(shade)
     if n==0:
      for r in c.paragraphs[0].runs:r.font.color.rgb=RGBColor(255,255,255)
   borders=OxmlElement('w:tblBorders')
   for side in ['top','left','bottom','right','insideH','insideV']:
    e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
   t._tbl.tblPr.append(borders)
  else:
   p=doc.add_paragraph(value,'Heading 2' if kind=='h' else None);rtl(p)
   if kind=='h':
    for r in p.runs:r.font.color.rgb=RGBColor.from_string('B91E31')
for style in doc.styles:
 for borders in list(style.element.iter(qn('w:pBdr'))):borders.getparent().remove(borders)
for borders in list(doc.element.iter(qn('w:pBdr'))):borders.getparent().remove(borders)
try:doc.save(OUT/'Rayan_Pedagogy_Chapter01.docx')
except PermissionError:
 (ROOT/'tmp').mkdir(exist_ok=True)
 doc.save(ROOT/'tmp/Rayan_Pedagogy_Chapter01.docx')
 print('Updated DOCX saved to tmp pending release of Word lock')
(OUT/'Rayan_Pedagogy_Chapter01.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'README.md').write_text('''# جزوه‌ی فصل اول پداگوژی رایان

این نسخه پیش‌نویس مطالعه‌ی مربی است و از متن و نمودارهای قابل مشاهده ساخته شده است. صوت مدرس در دسترس ابزار نبود و هنوز تطبیق شنیداری انجام نشده است.

قالب: A5 افقی، متن راست‌به‌چپ، قلم B Nazanin، لوگوی اصلی رایان، سرمه‌ای 14334D، زرشکی B91E31 و واترمارک رایان.

مثال کاربردی فرضی است. نام بخش‌های فرایند از نمودار فصل آمده است؛ شرح کار مربی تدوین تکمیلی است.

منبع: https://itcsam.ir/Files/SCORM_Courses/Course2840/6ce8b8bf-2cfd-434f-989e-f51a264d7629/index_lms_html5.html

برای تکمیل: دریافت صوت یا ویدئوی فصل اول، تطبیق متن با گفتار، تکمیل تعریف پداگوژی و بازبینی بخش آموزش اثربخش.

مخزن جدید پیشنهادی: rayan-pedagogy-course-notes-2026
''',encoding='utf-8')
print(OUT/'Rayan_Pedagogy_Chapter01.docx')
style='''@font-face{font-family:Naz;src:url(file:///C:/Windows/Fonts/BNazanin.ttf)}@font-face{font-family:Naz;src:url(file:///C:/Windows/Fonts/BNaznnBd.ttf);font-weight:700}@page{size:210mm 148mm;margin:0}*{box-sizing:border-box}body{margin:0;font-family:Naz;color:#14334D;direction:rtl;background:#ddd}.page{position:relative;width:210mm;height:148mm;background:#fffdfb;padding:8mm 13mm 17mm;break-after:page;overflow:hidden;border-bottom:2mm solid #14334D}.page:last-child{break-after:auto}header{height:17mm;display:flex;align-items:center;justify-content:space-between;color:#14334D;font-size:10pt;border-bottom:.4mm solid #B91E31}header img{width:22mm;height:16mm;object-fit:contain}h1{font-size:19pt;color:#14334D;margin:4mm 0 3mm}h2{font-size:13pt;color:#B91E31;margin:2mm 0 1mm}p{font-size:12pt;line-height:1.32;margin:1mm 0 1.5mm}main{position:relative;z-index:1}footer{position:absolute;bottom:4mm;left:13mm;right:13mm;display:flex;justify-content:space-between;font-size:10pt;border-top:.2mm solid #ddd;padding-top:2mm}.wm{position:absolute;top:53mm;left:67mm;font-size:78pt;color:#ece7e8;transform:rotate(-30deg);z-index:0}table{width:100%;border-collapse:collapse;font-size:11pt;margin:3mm 0}td{border:1px solid #d9d9d9;padding:1.4mm 2mm}tr:first-child{background:#14334D;color:white}tr:nth-child(even){background:#f2f4f6}td:first-child{width:36mm}@media print{body{background:white}}'''
body=[]
for i,(title,items) in enumerate(pages):
 content=''
 for kind,value in items:
  if kind=='table':content+='<table>'+''.join('<tr>'+''.join('<td>'+html.escape(t)+'</td>' for t in row)+'</tr>' for row in value)+'</table>'
  else:content+=f'<{"h2" if kind=="h" else "p"}>{html.escape(value)}</{"h2" if kind=="h" else "p"}>'
 body.append(f'<section class="page"><div class="wm">رایان</div><header><img src="assets/rayan-logo.png"><span>آموزشگاه رایان | پداگوژی | فصل اول</span></header><main><h1>{title}</h1>{content}</main><footer><span>پیش‌نویس بر اساس اسلایدها</span><span>رایان | {i+1}</span></footer></section>')
(OUT/'Rayan_Pedagogy_Chapter01.html').write_text('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>فصل اول پداگوژی رایان</title><style>'+style+'</style><body>'+''.join(body)+'</body></html>',encoding='utf-8')


