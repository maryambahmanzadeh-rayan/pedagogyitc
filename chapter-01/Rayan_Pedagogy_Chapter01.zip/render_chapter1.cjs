const {chromium}=require('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-737-0_26.1112.737.0_x64__3k8sg7r9htsxt/dependencies/node/node_modules/playwright');
const path=require('path');const fs=require('fs');
(async()=>{const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});const p=await browser.newPage({deviceScaleFactor:1.5});await p.goto('file:///'+path.resolve('output/Rayan_Pedagogy_Chapter01.html').replace(/\\/g,'/'));await p.evaluate(()=>document.fonts.ready);fs.mkdirSync('tmp/qa',{recursive:true});
console.log(await p.evaluate(()=>Array.from(document.querySelectorAll('.page')).map((pg,i)=>({page:i+1,mainBottom:pg.querySelector('main').getBoundingClientRect().bottom-pg.getBoundingClientRect().top,footerTop:pg.querySelector('footer').getBoundingClientRect().top-pg.getBoundingClientRect().top,overflow:pg.scrollHeight>pg.clientHeight}))));
await p.pdf({path:'output/Rayan_Pedagogy_Chapter01.pdf',printBackground:true,preferCSSPageSize:true});for(let i=0;i<4;i++)await p.locator('.page').nth(i).screenshot({path:`tmp/qa/page-${i+1}.png`});await browser.close()})()

