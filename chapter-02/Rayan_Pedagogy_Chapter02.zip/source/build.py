from pathlib import Path
import json, html
ROOT=Path(__file__).resolve().parent.parent
pages=json.loads((ROOT/'source/content.json').read_text(encoding='utf-8'))
style=(ROOT/'source/theme.css').read_text(encoding='utf-8')
def esc(s):return html.escape(s)
body=[]
for i,page in enumerate(pages):
 content=''
 for kind,value in page['items']:
  if kind=='table':
   content+='<table>'+''.join('<tr>'+''.join('<td>'+esc(t)+'</td>' for t in row)+'</tr>' for row in value)+'</table>'
  else:
   tag='h2' if kind=='h' else 'p'
   content+=f'<{tag}>{esc(value)}</{tag}>'
 number=str(i+1).translate(str.maketrans('0123456789','۰۱۲۳۴۵۶۷۸۹'))
 body.append(f'<section class="page"><div class="wm" aria-hidden="true">رایان</div><header><img src="assets/rayan-logo.png" alt="لوگوی آموزشگاه رایان"><span>آموزشگاه رایان | پداگوژی | فصل دوم</span></header><main><h1>{esc(page["title"])}</h1>{content}</main><footer><span>پیش‌نویس بر اساس اسلایدها</span><span>رایان | {number}</span></footer></section>')
(ROOT/'Rayan_Pedagogy_Chapter02.html').write_text('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>فصل دوم نیازسنجی آموزشی رایان</title><style>'+style+'</style><body>'+''.join(body)+'</body></html>',encoding='utf-8')
(ROOT/'Rayan_Pedagogy_Chapter02.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'Built {len(pages)} source pages')
