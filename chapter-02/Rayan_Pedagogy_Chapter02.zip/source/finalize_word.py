from pathlib import Path
from docx import Document
from docx.shared import Mm, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

root=Path(__file__).resolve().parent.parent
doc=Document();s=doc.sections[0]
s.page_width=Mm(210);s.page_height=Mm(148)
s.top_margin=s.bottom_margin=s.left_margin=s.right_margin=Mm(0)
doc.core_properties.title='فصل دوم نیازسنجی آموزشی رایان'
doc.core_properties.subject='نسخه‌ی Word با صفحه‌بندی ثابت؛ منبع قابل ویرایش در بسته‌ی منبع است'
doc.core_properties.author='آموزشگاه رایان'
import json
count=len(json.loads((root/'source/content.json').read_text(encoding='utf-8')))
for i in range(count):
 p=doc.add_paragraph();p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=Pt(1)
 if i:p.paragraph_format.page_break_before=True
 r=p.add_run();r.font.size=Pt(1);r.font.name='B Nazanin'
 pic=r.add_picture(str(root/f'qa/page-{i+1}.png'),width=Mm(210),height=Mm(148))._inline
 anchor=OxmlElement('wp:anchor')
 for k,v in {'distT':'0','distB':'0','distL':'0','distR':'0','simplePos':'0','relativeHeight':'0','behindDoc':'1','locked':'0','layoutInCell':'1','allowOverlap':'1'}.items():anchor.set(k,v)
 sp=OxmlElement('wp:simplePos');sp.set('x','0');sp.set('y','0');anchor.append(sp)
 for axis in ['H','V']:
  pos=OxmlElement('wp:position'+axis);pos.set('relativeFrom','page');off=OxmlElement('wp:posOffset');off.text='0';pos.append(off);anchor.append(pos)
 anchor.append(pic.find(qn('wp:extent')));anchor.append(OxmlElement('wp:wrapNone'))
 for name in ['wp:docPr','wp:cNvGraphicFramePr','a:graphic']:
  e=pic.find(qn(name))
  if e is not None:anchor.append(e)
 anchor.find(qn('wp:docPr')).set('descr',f'صفحه‌ی {i+1} جزوه‌ی پداگوژی رایان با قلم بی‌نازنین')
 pic.getparent().replace(pic,anchor)
doc.save(root/'Rayan_Pedagogy_Chapter02.docx')
print('Saved fixed-layout Word pages. Editable content is in HTML and JSON sources.')

