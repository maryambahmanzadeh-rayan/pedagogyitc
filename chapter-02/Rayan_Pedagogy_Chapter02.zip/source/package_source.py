from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parent.parent
paths=[root/'README.md',root/'Rayan_Pedagogy_Chapter02.html',root/'Rayan_Pedagogy_Chapter02.json',root/'assets/rayan-logo.png',root/'assets/rayan-watermark.png']
paths+=sorted(p for p in (root/'source').iterdir() if p.is_file() and p.suffix in {'.json','.css','.py','.cjs'})
with ZipFile(root/'Rayan_Pedagogy_Chapter02.zip','w',ZIP_DEFLATED) as z:
 for p in paths:z.write(p,p.relative_to(root))
print('Packaged',len(paths),'project source files')
