const path=require('path'),fs=require('fs');
const runtime=process.env.RAYAN_RUNTIME||'C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1112-737-0_26.1112.737.0_x64__3k8sg7r9htsxt/dependencies';
const {chromium}=require(path.join(runtime,'node/node_modules/playwright'));
const root=path.resolve(__dirname,'..'),qa=path.join(root,'qa');
(async()=>{const browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});try{
 const p=await browser.newPage({deviceScaleFactor:2});await p.goto(require('url').pathToFileURL(path.join(root,'Rayan_Pedagogy_Chapter02.html')).href);await p.evaluate(()=>document.fonts.ready);fs.mkdirSync(qa,{recursive:true});
 const checks=await p.evaluate(()=>Array.from(document.querySelectorAll('.page')).map((pg,i)=>{const b=pg.getBoundingClientRect(),m=pg.querySelector('main').getBoundingClientRect(),f=pg.querySelector('footer').getBoundingClientRect();return {page:i+1,gap:f.top-m.bottom,mainRight:m.right-b.right,mainLeft:m.left-b.left}}));
 console.log(JSON.stringify(checks));if(checks.some(x=>x.gap<12||x.mainRight>0||x.mainLeft<0))throw Error('Content does not fit safely before footer');
 await p.pdf({path:path.join(root,'Rayan_Pedagogy_Chapter02.pdf'),printBackground:true,preferCSSPageSize:true});for(let i=0;i<checks.length;i++)await p.locator('.page').nth(i).screenshot({path:path.join(qa,`page-${i+1}.png`)});
 fs.writeFileSync(path.join(qa,'layout-check.json'),JSON.stringify(checks,null,2));
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exit(1)});
