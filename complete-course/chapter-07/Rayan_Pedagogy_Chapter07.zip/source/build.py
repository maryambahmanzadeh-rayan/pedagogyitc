from pathlib import Path
import json,html
from docx import Document
from docx.shared import Mm,Pt,RGBColor
from docx.oxml import OxmlElement,parse_xml
from docx.oxml.ns import qn
from PIL import Image
dest=Path(__file__).resolve().parent.parent
source=dest/'source';assets=dest/'assets'
content=next(dest.glob('Rayan_Pedagogy_Chapter*.json'))
stem=content.stem;n=int(stem[-2:])
pages=json.loads(content.read_text(encoding='utf-8'))
css=(source/'theme.css').read_text(encoding='utf-8')
def fa(s):return str(s).translate(str.maketrans('0123456789','۰۱۲۳۴۵۶۷۸۹'))
def rtl(p):
 pr=p._p.get_or_add_pPr();b=OxmlElement('w:bidi');pr.append(b);p.alignment=2;return p
def para(doc,text,style=None):
 p=rtl(doc.add_paragraph(style=style));r=p.add_run(text);r.font.name='B Nazanin'
 rp=r._element.get_or_add_rPr();fs=rp.find(qn('w:rFonts'))
 if fs is None:fs=OxmlElement('w:rFonts');rp.insert(0,fs)
 for key in ['ascii','hAnsi','cs']:fs.set(qn('w:'+key),'B Nazanin')
 r.font.rtl=True;return p

NAMES=['', 'مبانی آموزش و پداگوژی', 'نیازسنجی آموزشی', 'طراحی آموزشی و تدوین اهداف', 'طرح درس', 'روش\u200cهای آموزش', 'فناوری و وسایل کمک\u200cآموزشی', 'اجرای آموزش', 'ارزشیابی آموزش']
body=[]
for i,p in enumerate(pages):
 items=p.get('items') or ([['h',p['subtitle']]]+[['p',t] for t in p['paragraphs']]+([['images',p['images']]] if p.get('images') else []))
 content=''
 for kind,value in items:
  if kind in ['h','p']:
   tag='h2' if kind=='h' else 'p';content+='<'+tag+'>'+html.escape(value)+'</'+tag+'>'
  else:content+='<figure class="'+('single' if len(value)==1 else 'quad' if len(value)>2 else 'pair')+'">'+''.join('<img src="'+im+'">' for im in value)+'</figure>'
 body.append('<section class="page"><div class="wm">رایان</div><header><img src="assets/rayan-logo.png"><span>رایان | پداگوژی | فصل '+fa(n)+'</span></header><main><h1>'+html.escape(p['title'])+'</h1>'+content+'</main><footer><span>پیاده‌سازی صوت و محتوای اسلایدها</span><span>'+fa(i+1)+'</span></footer></section>')
(dest/(stem+'.html')).write_text('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>'+NAMES[n]+'</title><style>'+css+'</style><body>'+''.join(body)+'</body></html>',encoding='utf-8')

doc=Document();section=doc.sections[0]
section.page_width=Mm(210);section.page_height=Mm(148)
section.top_margin=Mm(27);section.bottom_margin=Mm(15);section.left_margin=section.right_margin=Mm(13)
section.header_distance=Mm(5);section.footer_distance=Mm(5)
for sn in ['Normal','Title','Heading 1','Heading 2','Header','Footer']:
 point_size=12 if sn=='Normal' else 17 if sn in ['Title','Heading 1'] else 10 if sn in ['Header','Footer'] else 11
 st=doc.styles[sn];st.font.name='B Nazanin';st.font.size=Pt(point_size)
 st.font.color.rgb=RGBColor.from_string('14334D' if sn!='Heading 2' else 'B91E31')
 st.paragraph_format.space_before=Pt(0);st.paragraph_format.space_after=Pt(4);st.paragraph_format.line_spacing=1.12
 rp=st._element.get_or_add_rPr();fonts=rp.find(qn('w:rFonts'))
 if fonts is None:fonts=OxmlElement('w:rFonts');rp.insert(0,fonts)
 for key in list(fonts.attrib):
  if 'theme' in key.lower():del fonts.attrib[key]
 for key in ['ascii','hAnsi','cs']:fonts.set(qn('w:'+key),'B Nazanin')
 size_cs=rp.find(qn('w:szCs'))
 if size_cs is None:size_cs=OxmlElement('w:szCs');rp.append(size_cs)
 size_cs.set(qn('w:val'),str(point_size*2))
 borders=st._element.get_or_add_pPr().find(qn('w:pBdr'))
 if borders is not None:st._element.get_or_add_pPr().remove(borders)
hp=rtl(section.header.paragraphs[0]);hp.add_run().add_picture(str(assets/'rayan-logo.png'),width=Mm(18),height=Mm(13))
hp.add_run('   آموزشگاه رایان  |  پداگوژی  |  فصل '+fa(n)).font.name='B Nazanin'
pic=hp.add_run().add_picture(str(assets/'rayan-watermark.png'),width=Mm(100),height=Mm(60))._inline
anchor=OxmlElement('wp:anchor')
for key,value in {'distT':'0','distB':'0','distL':'0','distR':'0','simplePos':'0','relativeHeight':'0','behindDoc':'1','locked':'0','layoutInCell':'1','allowOverlap':'1'}.items():anchor.set(key,value)
sp=OxmlElement('wp:simplePos');sp.set('x','0');sp.set('y','0');anchor.append(sp)
for axis in ['H','V']:
 position=OxmlElement('wp:position'+axis);position.set('relativeFrom','page');align=OxmlElement('wp:align');align.text='center';position.append(align);anchor.append(position)
anchor.append(pic.find(qn('wp:extent')));anchor.append(OxmlElement('wp:wrapNone'))
for name in ['wp:docPr','wp:cNvGraphicFramePr','a:graphic']:
 child=pic.find(qn(name))
 if child is not None:anchor.append(child)
anchor.find(qn('wp:docPr')).set('descr','واترمارک رایان با قلم بی‌نازنین')
pic.getparent().replace(pic,anchor)
fp=rtl(section.footer.paragraphs[0]);fp.add_run('رایان  |  پیاده‌سازی صوت و محتوای اسلایدها  |  ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');fp._p.append(fld)
fld.set(qn('w:dirty'),'true');field_run=OxmlElement('w:r');field_text=OxmlElement('w:t');field_text.text='1';field_run.append(field_text);fld.append(field_run)
update_fields=OxmlElement('w:updateFields');update_fields.set(qn('w:val'),'true');doc.settings._element.append(update_fields)
for i,p in enumerate(pages):
 if i:doc.add_page_break()
 para(doc,p['title'],'Title' if i==0 else 'Heading 1')
 items=p.get('items') or ([['h',p['subtitle']]]+[['p',t] for t in p['paragraphs']]+([['images',p['images']]] if p.get('images') else []))
 for kind,value in items:
  if kind in ['h','p']:para(doc,value,'Heading 2' if kind=='h' else None)
  else:
   ip=rtl(doc.add_paragraph());ip.alignment=1;ip.paragraph_format.line_spacing=1.0
   for image_index,image_path in enumerate(value):
    if image_index and image_index%2==0:ip=rtl(doc.add_paragraph());ip.alignment=1;ip.paragraph_format.line_spacing=1.0
    im=assets/Path(image_path).name
    with Image.open(im) as image:w,h=image.size
    scale=min((170 if len(value)==1 else 81)/w,(34 if len(value)>2 else 73)/h)
    ip.add_run().add_picture(str(im),width=Mm(w*scale),height=Mm(h*scale));ip.add_run('  ')
doc.core_properties.title=NAMES[n];doc.core_properties.author='آموزشگاه رایان'
doc.core_properties.comments=''
doc.core_properties.subject='پیاده‌سازی فایل صوتی واقعی همراه با متن و تصاویر اسلایدها؛ نیازمند بازشنوی موارد علامت‌گذاری‌شده'
doc.save(dest/(stem+'.docx'))
