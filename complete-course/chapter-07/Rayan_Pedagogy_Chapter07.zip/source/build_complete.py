from pathlib import Path
import json,html,re,shutil,sys,zipfile,collections,math
from docx import Document
from docx.shared import Mm,Pt,RGBColor
from docx.oxml import OxmlElement,parse_xml
from docx.oxml.ns import qn
from PIL import Image
ROOT=Path(__file__).resolve().parent; PROJECT=ROOT.parent
OUT=PROJECT/'complete-course';OUT.mkdir(exist_ok=True)
NAMES=['','مبانی آموزش و پداگوژی','نیازسنجی آموزشی','طراحی آموزشی و تدوین اهداف','طرح درس','روش‌های آموزش','فناوری و وسایل کمک‌آموزشی','اجرای آموزش','ارزشیابی آموزش']
DISPLAY_TITLES={
 2:{5:'آموزش مبتنی بر نیاز',6:'منشأ نیاز آموزشی'},
 4:{8:'تعیین اهداف آموزشی',9:'بررسی وضعیت فراگیران',10:'تعیین محتوای درس',11:'انتخاب روش تدریس',12:'زمان‌بندی آموزش',13:'پیش‌بینی وسایل و مواد',14:'مراحل تهیه‌ی طرح درس'},
 5:{9:'آموزش مبتنی بر رایانه',10:'شبیه‌سازهای آموزشی',11:'بازی‌های آموزشی'},
 7:{5:'نقش و شایستگی مربی',7:'شایستگی‌های مربی آموزش فنی و حرفه‌ای'},
 8:{5:'چهار سطح ارزشیابی',7:'ویژگی‌های آزمون استاندارد',11:'تمرین حیطه‌های یادگیری'}
}
def display_title(n,s):return DISPLAY_TITLES.get(n,{}).get(s['order'],s['title'])
def fa(s):return str(s).translate(str.maketrans('0123456789','۰۱۲۳۴۵۶۷۸۹'))
def stamp(s):return f'{int(s)//60:02d}:{int(s)%60:02d}'
def chunks(text,limit=125):
 words=text.split();return [' '.join(words[i:i+limit]) for i in range(0,len(words),limit)]
def rtl(p):
 pr=p._p.get_or_add_pPr();b=OxmlElement('w:bidi');pr.append(b)
 p.alignment=2
 return p
def para(doc,text,style=None):
 p=rtl(doc.add_paragraph(style=style));r=p.add_run(text);r.font.name='B Nazanin'
 rp=r._element.get_or_add_rPr();fs=rp.find(qn('w:rFonts'))
 if fs is None:fs=OxmlElement('w:rFonts');rp.insert(0,fs)
 for key in ['ascii','hAnsi','cs']:fs.set(qn('w:'+key),'B Nazanin')
 r.font.rtl=True
 return p
def main(n):
 src=ROOT/f'chapter-{n:02d}';dest=OUT/f'chapter-{n:02d}';dest.mkdir(exist_ok=True)
 assets=dest/'assets';assets.mkdir(exist_ok=True)
 logo=PROJECT/'chapter-02/assets/rayan-logo.png';shutil.copy2(logo,assets/'rayan-logo.png')
 shutil.copy2(PROJECT/'chapter-02/assets/rayan-watermark.png',assets/'rayan-watermark.png')
 slides=json.loads((src/'slide-content.json').read_text(encoding='utf-8'))
 video_frames=json.loads((src/'video-frames.json').read_text(encoding='utf-8')) if (src/'video-frames.json').exists() else []
 extra_path=ROOT/f'extra-slides-{n:02d}.json'
 extra=json.loads(extra_path.read_text(encoding='utf-8')) if extra_path.exists() else {}
 audio=json.loads((src/'audio-index.json').read_text(encoding='utf-8'))
 transcripts={};missing=[]
 for a in audio:
  f=src/'transcripts'/(f'{a["order"]:02d}_'+Path(a['file']).stem+'.json')
  verified=src/'transcripts-turbo'/f.name
  if verified.exists():f=verified
  if f.exists():transcripts[str(a['asset_id'])]=json.loads(f.read_text(encoding='utf-8'))
  else:missing.append(a['file'])
 if missing:print('WAIT',n,len(missing),'audio transcripts missing');return
 edited_path=ROOT/f'edited-{n:02d}.json'
 edited=json.loads(edited_path.read_text(encoding='utf-8')) if edited_path.exists() else {}
 freq=collections.Counter(im['file'] for s in slides for im in s['images'])
 prefix_freq=collections.Counter(prefix for s in slides for prefix in {im['file'].split('_')[0] for im in s['images']})
 pages=[];coverage=[]
 def textpage(title,subtitle,paragraphs):
  current=[];count=0;lines=0
  for text in paragraphs:
   for part in chunks(text):
    size=len(part.split())
    cost=math.ceil(len(part)/90)+.55
    if current and (count+size>140 or lines+cost>11):pages.append({'title':title,'subtitle':subtitle,'paragraphs':current});current=[];count=0;lines=0
    current.append(part);count+=size;lines+=cost
  if current:pages.append({'title':title,'subtitle':subtitle,'paragraphs':current})
 textpage(f'فصل {fa(n)} {NAMES[n]}','راهنمای مطالعه و مبنای متن',[
  'این جزوه برای مربیان آموزشگاه رایان تهیه شده است. با خواندن جزوه می‌توانید توضیح مدرس را دنبال کنید و برای مرور، به متن، تصویر و صوت همان بخش برگردید. شماره‌ی اسلایدها از فهرست داخلی بسته‌ی اصلی گرفته شده است؛ بعضی صفحه‌ها در درس با پیوند باز می‌شوند.',
  'متن گفتار با پردازش فایل صوتی واقعی تهیه شده است. این نسخه پیاده‌سازی خودکار صوت است و بازشنوی انسانی کامل ندارد. اصلاح‌های نگارشی از متن خام و نوشته‌های همان اسلاید کمک گرفته‌اند. موارد نامطمئن با کروشه مشخص شده‌اند. متن اسلاید جای گفتار مدرس را نگرفته است.',
  f'این فصل {fa(len(slides))} اسلاید و {fa(len(audio))} فایل دارای صوت دارد. مدت کل فایل‌ها {fa(stamp(sum(a["duration_seconds"] for a in audio)))} است. زمان‌های زیر هر بخش نسبت به شروع همان فایل صوتی هستند. فایل‌های بدون گفتار قابل‌اعتماد نیز در فهرست پوشش ثبت شده‌اند.'
 ])
 textpage('فهرست اسلایدها','ترتیب ثبت‌شده در بسته‌ی اصلی دوره',[f'{fa(s["order"])}  {display_title(n,s)}' for s in slides])
 for s in slides:
  title=f'اسلاید {fa(s["order"])} {display_title(n,s)}'
  texts=[t for t in s['text'] if t.strip()!=s['title'].strip() and not re.search(r'\.(png|jpe?g|svg)\s*$',t,re.I) and t not in ['بعدی','قبلی','برای جزئیات بیشتر کلیک کنید']]
  textpage(title,'نوشته‌های استخراج‌شده از اسلاید',texts or ['این اسلاید متن فارسی مستقلی در منبع ندارد. تصویرها و وضعیت صوت در ادامه آمده‌اند.'])
  if str(s['order']) in extra:textpage(title,'نوشته‌های مشاهده‌شده در تصویرهای ویدئوی درس',extra[str(s['order'])])
  gallery=[]
  for im in s['images']:
   if freq[im['file']]>=max(3,len(slides)*0.5):continue
   if prefix_freq[im['file'].split('_')[0]]>=max(3,len(slides)*0.5):continue
   original=src/im['file']
   if not original.exists():raise FileNotFoundError(original)
   image_name=f's{s["order"]:02d}_'+im['file'];shutil.copy2(original,assets/image_name)
   gallery.append('assets/'+image_name)
  for start in range(0,len(gallery),4):
   pages.append({'title':title,'subtitle':'تصویرهای اصلی مرتبط با اسلاید به ترتیب منبع','images':gallery[start:start+4],'paragraphs':[]})
  if not s['audio_asset_ids']:textpage(title,'وضعیت صوت',['برای این اسلاید فایل صوتی جداگانه‌ای در منبع ثبت نشده است.'])
  for key in s['audio_asset_ids']:
   t=transcripts.get(key)
   if not t:continue
   video_images=[]
   for vf in video_frames:
    if vf['asset_id']!=key:continue
    image_name=f'video_s{s["order"]:02d}_'+Path(vf['file']).name
    shutil.copy2(src/vf['file'],assets/image_name)
    video_images.append(('assets/'+image_name,vf['time']))
   for start in range(0,len(video_images),2):
    group=video_images[start:start+2]
    pages.append({'title':title,'subtitle':'نماهای ویدئوی درس در زمان '+ ' و '.join(fa(stamp(x[1])) for x in group),'images':[x[0] for x in group],'paragraphs':[]})
   a=t['source'];segments=t['segments'];order=str(a['order']);sub=f'گفتار مدرس  فایل {fa(order)}  مدت {fa(stamp(a["duration_seconds"]))}'
   valid=[seg for seg in segments if seg['text'].strip(' []،,.').lower() not in ['موسیقی','music'] and (len(seg['text'].split())<15 or len(set(seg['text'].split()))/len(seg['text'].split())>.25)]
   if not valid:
    ps=['[در پردازش این فایل، گفتار کلامی قابل‌اعتماد شناسایی نشد. فایل اصلی برای بررسی و مرور محفوظ است.]'];status='no_reliable_speech_detected'
   elif order in edited:
    ps=[f'[{fa(stamp(valid[0]["start"]))} تا {fa(stamp(valid[-1]["end"]))}] متن ویرایش‌شده از خروجی صوت']+edited[order];status='edited_from_asr_and_slide'
   else:
    ps=[f'[{fa(stamp(seg["start"]))} تا {fa(stamp(seg["end"]))}] '+seg['text'].strip()+(' [واژه‌ها نیازمند بررسی صوت هستند.]' if seg.get('avg_logprob',0)<-.75 else '') for seg in valid];status='raw_asr_needs_editorial_review'
   textpage(title,sub,ps)
   coverage.append({'audio_order':a['order'],'slide':s['order'],'slide_title':display_title(n,s),'file':a['file'],'asset_id':a['asset_id'],'duration_seconds':a['duration_seconds'],'status':status,'raw_transcript_segments':len(segments)})
 textpage('فهرست پوشش صوت','کنترل کامل بودن منابع',[f'فایل {fa(x["audio_order"])}  اسلاید {fa(x["slide"])}  {x["slide_title"]}  مدت {fa(stamp(x["duration_seconds"]))}  '+('گفتار قابل‌شناسایی ثبت نشد' if x['status']=='no_reliable_speech_detected' else 'متن صوت ثبت شد') for x in sorted(coverage,key=lambda x:x['audio_order'])])
 textpage('منبع درس و شیوه‌ی تدوین','یادداشت منبع',[
  'منبع آموزشی، بسته‌ی پداگوژی در سامانه‌ی آموزش مجازی مرکز تربیت مربی فنی و حرفه‌ای به نشانی itcsam.ir است. آموزشگاه رایان، متن و تصویرهای درس را برای مطالعه‌ی مکتوب صفحه‌آرایی کرده است.',
  'گفتار از فایل صوتی اصلی به متن تبدیل شده است. متن خام دارای زمان و اطلاعات پردازش در بسته‌ی منبع محفوظ است. ویرایش گفتار، خطاهای روشن نگارشی را اصلاح می‌کند. نوشته‌های اسلاید، تصویرها و گفتار با عنوان جدا مشخص شده‌اند. این نسخه با بازشنوی انسانی کامل تطبیق داده نشده است.',
  'برای شنیدن فایل‌های اصلی، فهرست Audio_Library.html را در پوشه‌ی local-audio باز کنید. شماره‌ی هر فایل در آن فهرست با شماره‌ی درج‌شده در متن این فصل مطابقت دارد. عبارت‌های داخل کروشه، موارد نامطمئن یا یادداشت تدوین‌گر را مشخص می‌کنند.'
 ])
 assert len(coverage)==len(audio),(n,len(coverage),len(audio))
 stem=f'Rayan_Pedagogy_Chapter{n:02d}'
 (dest/(stem+'.json')).write_text(json.dumps(pages,ensure_ascii=False,indent=2),encoding='utf-8')
 (dest/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2),encoding='utf-8')
 source=dest/'source';source.mkdir(exist_ok=True)
 for name in ['slide-content.json','audio-index.json']:shutil.copy2(src/name,source/name)
 shutil.copy2(Path(__file__),source/'build_complete.py')
 shutil.copytree(src/'transcripts',source/'raw-transcripts',dirs_exist_ok=True)
 if (src/'transcripts-turbo').exists():shutil.copytree(src/'transcripts-turbo',source/'second-pass-transcripts',dirs_exist_ok=True)
 if edited_path.exists():shutil.copy2(edited_path,source/'edited-transcript.json')
 if extra_path.exists():shutil.copy2(extra_path,source/'extra-slides.json')
 css=(PROJECT/'chapter-02/source/theme.css').read_text(encoding='utf-8')+'\nfigure{margin:0;text-align:center;display:grid;grid-template-columns:1fr 1fr;justify-items:center;align-items:center;height:77mm}figure img{max-width:84mm;max-height:73mm;object-fit:contain}figure.single{grid-template-columns:1fr}figure.single img{max-width:170mm}figure.quad img{max-height:34mm}p{font-size:12pt;line-height:1.35}h1{font-size:17pt}h2{font-size:11pt}'
 body=[]
 for i,p in enumerate(pages):
  content='<h2>'+html.escape(p['subtitle'])+'</h2>'+''.join('<p>'+html.escape(t)+'</p>' for t in p['paragraphs'])
  if p.get('images'):content+='<figure class="'+('single' if len(p['images'])==1 else 'quad' if len(p['images'])>2 else 'pair')+'">'+''.join('<img src="'+im+'">' for im in p['images'])+'</figure>'
  body.append('<section class="page"><div class="wm">رایان</div><header><img src="assets/rayan-logo.png"><span>رایان | پداگوژی | فصل '+fa(n)+'</span></header><main><h1>'+html.escape(p['title'])+'</h1>'+content+'</main><footer><span>پیاده‌سازی صوت و محتوای اسلایدها</span><span>'+fa(i+1)+'</span></footer></section>')
 (dest/(stem+'.html')).write_text('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>'+NAMES[n]+'</title><style>'+css+'</style><body>'+''.join(body)+'</body></html>',encoding='utf-8')
 doc=Document();section=doc.sections[0]
 section.page_width=Mm(210);section.page_height=Mm(148)
 section.top_margin=Mm(27);section.bottom_margin=Mm(15);section.left_margin=section.right_margin=Mm(13)
 section.header_distance=Mm(5);section.footer_distance=Mm(5)
 for sn in ['Normal','Title','Heading 1','Heading 2','Header','Footer']:
  point_size=12 if sn=='Normal' else 17 if sn in ['Title','Heading 1'] else 10 if sn in ['Header','Footer'] else 11
  st=doc.styles[sn];st.font.name='B Nazanin';st.font.size=Pt(point_size)
  st.font.color.rgb=RGBColor.from_string('14334D' if sn!='Heading 2' else 'B91E31')
  st.paragraph_format.space_before=Pt(0);st.paragraph_format.space_after=Pt(4);st.paragraph_format.line_spacing=1.12
  rp=st._element.get_or_add_rPr();fonts=rp.find(qn('w:rFonts'))
  if fonts is None:fonts=OxmlElement('w:rFonts');rp.insert(0,fonts)
  for key in list(fonts.attrib):
   if 'theme' in key.lower():del fonts.attrib[key]
  for key in ['ascii','hAnsi','cs']:fonts.set(qn('w:'+key),'B Nazanin')
  size_cs=rp.find(qn('w:szCs'))
  if size_cs is None:size_cs=OxmlElement('w:szCs');rp.append(size_cs)
  size_cs.set(qn('w:val'),str(point_size*2))
  borders=st._element.get_or_add_pPr().find(qn('w:pBdr'))
  if borders is not None:st._element.get_or_add_pPr().remove(borders)
 hp=rtl(section.header.paragraphs[0]);hp.add_run().add_picture(str(assets/'rayan-logo.png'),width=Mm(18),height=Mm(13))
 hp.add_run('   آموزشگاه رایان  |  پداگوژی  |  فصل '+fa(n)).font.name='B Nazanin'
 pic=hp.add_run().add_picture(str(assets/'rayan-watermark.png'),width=Mm(100),height=Mm(60))._inline
 anchor=OxmlElement('wp:anchor')
 for key,value in {'distT':'0','distB':'0','distL':'0','distR':'0','simplePos':'0','relativeHeight':'0','behindDoc':'1','locked':'0','layoutInCell':'1','allowOverlap':'1'}.items():anchor.set(key,value)
 sp=OxmlElement('wp:simplePos');sp.set('x','0');sp.set('y','0');anchor.append(sp)
 for axis in ['H','V']:
  position=OxmlElement('wp:position'+axis);position.set('relativeFrom','page');align=OxmlElement('wp:align');align.text='center';position.append(align);anchor.append(position)
 anchor.append(pic.find(qn('wp:extent')));anchor.append(OxmlElement('wp:wrapNone'))
 for name in ['wp:docPr','wp:cNvGraphicFramePr','a:graphic']:
  child=pic.find(qn(name))
  if child is not None:anchor.append(child)
 anchor.find(qn('wp:docPr')).set('descr','واترمارک رایان با قلم بی‌نازنین')
 pic.getparent().replace(pic,anchor)
 fp=rtl(section.footer.paragraphs[0]);fp.add_run('رایان  |  پیاده‌سازی صوت و محتوای اسلایدها  |  ')
 fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');fp._p.append(fld)
 fld.set(qn('w:dirty'),'true');field_run=OxmlElement('w:r');field_text=OxmlElement('w:t');field_text.text='1';field_run.append(field_text);fld.append(field_run)
 update_fields=OxmlElement('w:updateFields');update_fields.set(qn('w:val'),'true');doc.settings._element.append(update_fields)
 for i,p in enumerate(pages):
  if i:doc.add_page_break()
  para(doc,p['title'],'Title' if i==0 else 'Heading 1');para(doc,p['subtitle'],'Heading 2')
  for text in p['paragraphs']:para(doc,text)
  if p.get('images'):
   ip=rtl(doc.add_paragraph());ip.alignment=1
   for image_index,image_path in enumerate(p['images']):
    if image_index and image_index%2==0:ip=rtl(doc.add_paragraph());ip.alignment=1
    im=assets/Path(image_path).name
    with Image.open(im) as image:w,h=image.size
    scale=min((170 if len(p['images'])==1 else 81)/w,(34 if len(p['images'])>2 else 73)/h)
    ip.add_run().add_picture(str(im),width=Mm(w*scale),height=Mm(h*scale));ip.add_run('  ')
 doc.core_properties.title=NAMES[n];doc.core_properties.author='آموزشگاه رایان'
 doc.core_properties.comments=''
 doc.core_properties.subject='پیاده‌سازی فایل صوتی واقعی همراه با متن و تصاویر اسلایدها؛ نیازمند بازشنوی موارد علامت‌گذاری‌شده'
 doc.save(dest/(stem+'.docx'))
 (dest/'README.md').write_text('# '+NAMES[n]+'\n\nنسخه‌ی مبتنی بر فایل صوتی واقعی و محتوای اسلایدها. ترتیب اسلایدها مطابق فهرست بسته‌ی اصلی است. متن Word قابل ویرایش است. پیاده‌سازی صوت خودکار است و بازشنوی انسانی کامل انجام نشده است. وضعیت هر فایل در coverage.json آمده است. فایل‌های صوتی اصلی در پوشه‌ی محلی local-audio نگهداری می‌شوند.\n',encoding='utf-8')
 print('BUILT',n,len(pages),'pages',len(coverage),'audio files')
if __name__=='__main__':
 for n in map(int,sys.argv[1:] or range(1,9)):main(n)
